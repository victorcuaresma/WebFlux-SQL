package pe.edu.vallegrande.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsSpringWebfluxR2dbcSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsSpringWebfluxR2dbcSqlApplication.class, args);
	}

}
