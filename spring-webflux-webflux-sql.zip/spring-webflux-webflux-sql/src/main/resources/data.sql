INSERT INTO customer (dni, first_name, last_name, state) 
VALUES ('12345678', 'Juan', 'Sanchez', 'A');
